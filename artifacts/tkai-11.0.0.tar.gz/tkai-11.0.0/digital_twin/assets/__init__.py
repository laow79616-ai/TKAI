"""Twin-managed asset interfaces."""
