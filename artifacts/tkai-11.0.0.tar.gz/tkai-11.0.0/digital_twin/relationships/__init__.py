"""Typed digital twin relationships."""
