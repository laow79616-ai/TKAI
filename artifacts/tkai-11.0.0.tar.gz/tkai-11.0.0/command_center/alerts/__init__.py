"""Alert lifecycle management."""
