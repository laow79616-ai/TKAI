"""Command Center overview projections."""
