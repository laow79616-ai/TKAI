"""Versioned operational playbooks."""
