"""Automation operational projections."""
