"""Intelligence profile domain boundary."""
