"""Installation lifecycle contracts."""
