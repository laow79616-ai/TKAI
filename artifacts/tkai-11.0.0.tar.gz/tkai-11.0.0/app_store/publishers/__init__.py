"""Publisher profile contracts."""
