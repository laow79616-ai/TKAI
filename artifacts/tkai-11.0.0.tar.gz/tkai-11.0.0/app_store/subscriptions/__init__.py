"""Subscription entitlement contracts."""
