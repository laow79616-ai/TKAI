"""Store application contracts."""
