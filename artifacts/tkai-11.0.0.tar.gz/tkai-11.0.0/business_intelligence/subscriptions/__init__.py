"""Scheduled BI delivery contracts."""
