"""BI governance contracts."""
