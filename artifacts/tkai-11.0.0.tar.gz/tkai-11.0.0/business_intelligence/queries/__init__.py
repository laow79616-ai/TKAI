"""Bounded analytical query contracts."""
