"""BI workspace lifecycle contracts."""
