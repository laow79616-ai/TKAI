"""Bounded business measure definitions."""
