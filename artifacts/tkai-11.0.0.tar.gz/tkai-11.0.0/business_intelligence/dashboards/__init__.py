"""Versioned dashboard contracts."""
