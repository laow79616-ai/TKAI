"""Governed report contracts."""
