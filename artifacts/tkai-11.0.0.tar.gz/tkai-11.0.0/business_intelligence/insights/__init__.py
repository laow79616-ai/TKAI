"""Evidence-backed insight contracts."""
