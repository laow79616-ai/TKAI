"""Versioned BI dataset contracts."""
