"""Safe visualization contracts."""
