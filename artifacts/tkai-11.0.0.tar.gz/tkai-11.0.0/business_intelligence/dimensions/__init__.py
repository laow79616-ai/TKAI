"""Business dimension definitions."""
