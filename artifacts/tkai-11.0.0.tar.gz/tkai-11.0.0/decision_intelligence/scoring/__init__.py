"""Weighted scoring strategies."""
