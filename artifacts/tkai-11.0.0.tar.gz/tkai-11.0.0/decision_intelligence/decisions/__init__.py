"""Decision lifecycle domain."""
