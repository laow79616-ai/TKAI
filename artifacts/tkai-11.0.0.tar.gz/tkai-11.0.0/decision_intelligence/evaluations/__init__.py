"""Multi-criteria evaluation domain."""
