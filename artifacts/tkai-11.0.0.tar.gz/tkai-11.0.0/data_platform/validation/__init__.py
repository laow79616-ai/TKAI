from data_platform.platform import validate_schema as validate_schema
