"""Ordered pipeline transformation contracts."""
