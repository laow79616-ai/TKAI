"""Project capabilities."""
