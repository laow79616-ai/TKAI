"""Collaboration activity capabilities."""
