"""Collaboration session capabilities."""
