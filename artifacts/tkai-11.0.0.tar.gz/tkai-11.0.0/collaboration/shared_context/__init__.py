"""Shared context capabilities."""
