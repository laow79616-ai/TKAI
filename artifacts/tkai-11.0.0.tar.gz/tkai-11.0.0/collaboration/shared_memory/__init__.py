"""Shared memory capabilities."""
