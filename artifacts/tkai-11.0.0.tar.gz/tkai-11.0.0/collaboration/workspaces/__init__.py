"""Workspace capabilities."""
