"""Team collaboration capabilities."""
