"""Collaboration role capabilities."""
