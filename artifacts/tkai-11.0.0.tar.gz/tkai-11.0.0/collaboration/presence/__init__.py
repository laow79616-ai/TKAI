"""Participant presence capabilities."""
