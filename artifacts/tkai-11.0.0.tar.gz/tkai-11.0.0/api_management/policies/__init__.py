"""Gateway policy domain."""
