"""Managed API domain."""
