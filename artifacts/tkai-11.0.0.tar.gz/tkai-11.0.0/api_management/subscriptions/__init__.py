"""Consumer subscription lifecycle domain."""
