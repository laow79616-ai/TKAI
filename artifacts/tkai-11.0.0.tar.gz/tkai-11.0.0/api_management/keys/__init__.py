"""API key reference domain."""
