"""Bounded quota domain."""
