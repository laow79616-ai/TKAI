"""Bounded working-memory contracts."""
